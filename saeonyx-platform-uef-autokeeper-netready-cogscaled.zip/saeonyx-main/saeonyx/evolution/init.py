"""
SAEONYX Evolution Engine
Genetic operators and fitness evaluation.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

__version__ = "1.0"
__author__ = "Jake McDonough"
__email__ = "jake@saeonyx.com"

from .engine import EvolutionEngine

__all__ = ["EvolutionEngine"]
