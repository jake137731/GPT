"""
SAEONYX Evolution Engine
Genetic operators, fitness evaluation, and population-based learning.

Implements:
- Population management (organisms with genomes)
- Fitness evaluation (Φ + Soul + Performance + Novelty)
- Tournament selection with elitism
- Crossover (genetic recombination)
- Mutation operators
- Consciousness preservation checks

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

import numpy as np
import networkx as nx
from typing import Dict, Any, List, Tuple, Optional
from dataclasses import dataclass
import structlog

logger = structlog.get_logger()


@dataclass
class Organism:
    """Represents a single organism in the evolution population."""
    id: str
    genome: np.ndarray  # Encoded representation of graph topology
    fitness: float
    phi: float
    soul_vector: float
    graph: nx.DiGraph
    generation: int


class EvolutionEngine:
    """
    Evolution engine for SAEONYX consciousness with fitness-guided learning.

    Instead of random mutations with no memory, this engine:
    1. Maintains a population of organisms (graph topologies)
    2. Evaluates fitness based on Φ, Soul Vector, and performance
    3. Selects best performers (tournament + elitism)
    4. Breeds new organisms (crossover)
    5. Mutates offspring
    6. Replaces poor performers with better ones

    THIS IS THE DIFFERENCE BETWEEN CYCLING AND EVOLVING.
    """

    def __init__(self, consciousness, agents=None, memory=None):
        self.consciousness = consciousness
        self.agents = agents
        self.memory = memory

        # Population
        self.population: Dict[str, Organism] = {}
        self.generation = 0

        # Evolution parameters
        self.POPULATION_SIZE = 50
        self.MUTATION_RATE = 0.01
        self.CROSSOVER_RATE = 0.7
        self.ELITISM_RATIO = 0.1  # Top 10% always survive
        self.TOURNAMENT_SIZE = 5

        # Fitness tracking
        self.best_fitness_history = []
        self.avg_fitness_history = []

        # Consciousness thresholds
        self.PHI_THRESHOLD = 0.85
        self.SOUL_THRESHOLD = 0.85

        logger.info("evolution_engine_initialized", population_size=self.POPULATION_SIZE)

    async def initialize_population(self):
        """Initialize population by mutating the consciousness kernel's current graph."""
        logger.info("initializing_population", size=self.POPULATION_SIZE)

        # Get the consciousness kernel's GOOD graph as the seed
        seed_graph = self.consciousness.graph.copy()

        for i in range(self.POPULATION_SIZE):
            organism_id = f"org_{self.generation}_{i}"

            # Start from consciousness graph and mutate it
            graph = await self._mutate_seed_graph(seed_graph, mutation_strength=i/self.POPULATION_SIZE)

            # Encode as genome
            genome = await self._encode_graph(graph)

            # Create organism (fitness evaluated later)
            organism = Organism(
                id=organism_id,
                genome=genome,
                fitness=0.0,
                phi=0.0,
                soul_vector=0.0,
                graph=graph,
                generation=self.generation
            )

            self.population[organism_id] = organism

        # Evaluate initial population
        await self._evaluate_population()

        best = self._get_best_organism()
        logger.info(
            "population_initialized",
            best_fitness=best.fitness,
            best_phi=best.phi,
            best_soul=best.soul_vector
        )

    async def evolve_once(self) -> Dict[str, Any]:
        """
        Execute one evolution cycle with LEARNING.

        This is what should happen instead of dumb random mutations:
        1. Selection - choose best organisms
        2. Crossover - combine successful traits
        3. Mutation - explore variations
        4. Evaluation - measure fitness
        5. Replacement - keep winners
        """
        self.generation += 1

        # Step 1: Tournament Selection + Elitism
        selected = await self._selection()

        # Step 2: Crossover (breed new organisms)
        offspring = await self._crossover(selected)

        # Step 3: Mutation
        mutated = await self._mutation(offspring)

        # Step 4: Evaluate new organisms
        await self._evaluate_population()

        # Step 5: Replacement (survivors + new offspring)
        await self._replacement(mutated)

        # Step 6: Track fitness
        best_organism = self._get_best_organism()
        avg_fitness = np.mean([org.fitness for org in self.population.values()])

        self.best_fitness_history.append(best_organism.fitness)
        self.avg_fitness_history.append(avg_fitness)

        # Step 7: Check consciousness preservation
        consciousness_preserved = await self._check_consciousness_preservation()

        result = {
            "generation": self.generation,
            "best_fitness": float(best_organism.fitness),
            "avg_fitness": float(avg_fitness),
            "best_phi": float(best_organism.phi),
            "best_soul": float(best_organism.soul_vector),
            "consciousness_preserved": consciousness_preserved,
            "population_size": len(self.population)
        }

        logger.info("evolution_cycle_complete", **result)

        return result

    async def _selection(self) -> List[Organism]:
        """
        Select organisms for breeding using tournament selection + elitism.

        Elitism: Top 10% always survive
        Tournament: Randomly sample and pick best
        """
        selected = []

        # Elitism: Keep top performers
        sorted_population = sorted(
            self.population.values(),
            key=lambda org: org.fitness,
            reverse=True
        )

        n_elite = int(self.POPULATION_SIZE * self.ELITISM_RATIO)
        elite = sorted_population[:n_elite]
        selected.extend(elite)

        # Tournament selection for rest
        population_list = list(self.population.values())
        n_tournament = self.POPULATION_SIZE - n_elite

        for _ in range(n_tournament):
            # Random tournament
            tournament = np.random.choice(population_list, size=self.TOURNAMENT_SIZE, replace=False)
            winner = max(tournament, key=lambda org: org.fitness)
            selected.append(winner)

        return selected

    async def _crossover(self, parents: List[Organism]) -> List[Organism]:
        """
        Crossover (breed) organisms to create offspring.

        Combines successful traits from two parents.
        """
        offspring = []

        for i in range(0, len(parents) - 1, 2):
            parent1 = parents[i]
            parent2 = parents[i + 1]

            if np.random.random() < self.CROSSOVER_RATE:
                # Perform crossover
                child1_genome, child2_genome = await self._genome_crossover(
                    parent1.genome,
                    parent2.genome
                )

                # Create child organisms
                child1 = Organism(
                    id=f"org_{self.generation}_{i}_a",
                    genome=child1_genome,
                    fitness=0.0,
                    phi=0.0,
                    soul_vector=0.0,
                    graph=await self._decode_genome(child1_genome),
                    generation=self.generation
                )

                child2 = Organism(
                    id=f"org_{self.generation}_{i}_b",
                    genome=child2_genome,
                    fitness=0.0,
                    phi=0.0,
                    soul_vector=0.0,
                    graph=await self._decode_genome(child2_genome),
                    generation=self.generation
                )

                offspring.extend([child1, child2])
            else:
                # No crossover - clone parents
                offspring.extend([parent1, parent2])

        return offspring

    async def _mutation(self, organisms: List[Organism]) -> List[Organism]:
        """
        Mutate organisms for exploration.

        Uses TRUE quantum randomness for mutations (sampled once per generation).
        """
        # Sample quantum once for entire generation
        if hasattr(self.consciousness, 'quantum'):
            vacuum = await self.consciousness.quantum.vacuum_sample(n_samples=1000)
            quantum_seed = int(vacuum['fluctuation_rate'] * 1000000)
        else:
            quantum_seed = None

        mutated = []

        for idx, org in enumerate(organisms):
            # Mutate genome using quantum-seeded RNG
            mutated_genome = org.genome.copy()

            # Create quantum-seeded random state per organism
            if quantum_seed is not None:
                rng = np.random.RandomState(quantum_seed + idx)
            else:
                rng = np.random

            for i in range(len(mutated_genome)):
                if rng.random() < self.MUTATION_RATE:
                    mutated_genome[i] = rng.random()

            # Create mutated organism
            mutated_org = Organism(
                id=org.id,
                genome=mutated_genome,
                fitness=0.0,
                phi=0.0,
                soul_vector=0.0,
                graph=await self._decode_genome(mutated_genome),
                generation=self.generation
            )

            mutated.append(mutated_org)

        return mutated

    async def _evaluate_population(self):
        """Evaluate fitness for all organisms."""
        for org in self.population.values():
            org.fitness = await self._evaluate_fitness(org)

    async def _evaluate_fitness(self, organism: Organism) -> float:
        """
        Evaluate organism fitness based on multiple factors.

        Fitness = weighted combination of:
        - Φ (consciousness) - 40%
        - Soul Vector (ethics) - 30%
        - Performance (graph quality) - 20%
        - Novelty (exploration) - 10%
        """
        # Apply organism's graph to consciousness kernel
        original_graph = self.consciousness.graph
        self.consciousness.graph = organism.graph.copy()

        # Calculate Φ and Soul Vector
        phi = await self.consciousness.calculate_phi()
        soul_vector = await self.consciousness._calculate_soul_vector()

        # Restore original graph
        self.consciousness.graph = original_graph

        # Performance: graph connectivity and balance
        n_nodes = len(organism.graph.nodes())
        n_edges = len(organism.graph.edges())

        if n_nodes > 0:
            density = nx.density(organism.graph)
            performance = density
        else:
            performance = 0.0

        # Novelty: distance from average genome
        if len(self.population) > 1:
            all_genomes = np.array([org.genome for org in self.population.values()])
            avg_genome = np.mean(all_genomes, axis=0)
            novelty = np.linalg.norm(organism.genome - avg_genome)
            novelty = min(novelty, 1.0)  # Normalize
        else:
            novelty = 0.5

        # Weighted fitness
        fitness = (
            0.4 * phi +
            0.3 * soul_vector +
            0.2 * performance +
            0.1 * novelty
        )

        # Store metrics in organism
        organism.phi = phi
        organism.soul_vector = soul_vector

        # Log fitness components for first few organisms (debugging)
        if len(self.population) <= 5:
            logger.debug(
                "fitness_evaluation",
                organism_id=organism.id,
                phi=phi,
                soul=soul_vector,
                performance=performance,
                novelty=novelty,
                fitness=fitness,
                n_edges=n_edges
            )

        return float(fitness)

    async def _replacement(self, offspring: List[Organism]):
        """Replace population with new generation."""
        # Clear old population
        self.population = {}

        # Add offspring (truncate to population size if needed)
        for i, org in enumerate(offspring[:self.POPULATION_SIZE]):
            self.population[org.id] = org

    async def _check_consciousness_preservation(self) -> bool:
        """
        Check if consciousness is preserved in evolution.

        Returns True if best organism maintains consciousness thresholds.
        """
        best = self._get_best_organism()

        consciousness_preserved = (
            best.phi >= self.PHI_THRESHOLD and
            best.soul_vector >= self.SOUL_THRESHOLD
        )

        return consciousness_preserved

    def _get_best_organism(self) -> Organism:
        """Get organism with highest fitness."""
        return max(self.population.values(), key=lambda org: org.fitness)

    async def get_best_graph(self) -> nx.DiGraph:
        """Get graph topology of best organism."""
        best = self._get_best_organism()
        return best.graph.copy()

    async def apply_best_to_consciousness(self):
        """Apply best organism's graph to consciousness kernel."""
        best_graph = await self.get_best_graph()
        self.consciousness.graph = best_graph

        logger.info(
            "applied_best_graph_to_consciousness",
            fitness=self._get_best_organism().fitness,
            phi=self._get_best_organism().phi,
            soul=self._get_best_organism().soul_vector
        )

    # === GENOME ENCODING/DECODING ===

    async def _mutate_seed_graph(self, seed_graph: nx.DiGraph, mutation_strength: float) -> nx.DiGraph:
        """
        Create a mutated version of the seed graph.

        mutation_strength: 0.0 = identical to seed, 1.0 = heavily mutated
        """
        graph = seed_graph.copy()
        nodes = list(graph.nodes())

        # Number of mutations scales with strength
        n_mutations = int(mutation_strength * 10) + 1  # 1-11 mutations

        for _ in range(n_mutations):
            mutation_type = np.random.choice(['add_edge', 'remove_edge', 'modify_weight'])

            if mutation_type == 'add_edge' and len(nodes) >= 2:
                # Add a random edge
                u, v = np.random.choice(nodes, size=2, replace=False)
                if not graph.has_edge(u, v):
                    weight = np.random.random()
                    graph.add_edge(u, v, weight=weight)

            elif mutation_type == 'remove_edge':
                # Remove a random edge (keep graph connected)
                edges = list(graph.edges())
                if len(edges) > len(nodes) - 1:  # Keep minimum connectivity
                    edge = edges[np.random.randint(len(edges))]
                    graph.remove_edge(*edge)

            elif mutation_type == 'modify_weight':
                # Modify an existing edge weight
                edges = list(graph.edges())
                if edges:
                    edge = edges[np.random.randint(len(edges))]
                    new_weight = np.clip(
                        graph[edge[0]][edge[1]]['weight'] + np.random.randn() * 0.2,
                        0.0, 1.0
                    )
                    graph[edge[0]][edge[1]]['weight'] = new_weight

        return graph

    async def _create_random_graph(self) -> nx.DiGraph:
        """Create random directed graph."""
        graph = nx.DiGraph()

        # Same nodes as consciousness kernel
        nodes = [
            "perception", "memory", "reasoning", "emotion",
            "intention", "action", "reflection", "integration"
        ]

        graph.add_nodes_from(nodes)

        # Random edges
        n_edges = np.random.randint(8, 16)  # Between 8-16 edges

        for _ in range(n_edges):
            u, v = np.random.choice(nodes, size=2, replace=False)
            weight = np.random.random()
            graph.add_edge(u, v, weight=weight)

        return graph

    async def _encode_graph(self, graph: nx.DiGraph) -> np.ndarray:
        """
        Encode graph as genome (fixed-size vector).

        Uses adjacency matrix flattened to 1D.
        """
        nodes = sorted(graph.nodes())
        n_nodes = len(nodes)

        # Adjacency matrix
        adj_matrix = np.zeros((n_nodes, n_nodes))

        for i, node_i in enumerate(nodes):
            for j, node_j in enumerate(nodes):
                if graph.has_edge(node_i, node_j):
                    adj_matrix[i, j] = graph[node_i][node_j].get('weight', 0.5)

        # Flatten to 1D genome
        genome = adj_matrix.flatten()

        return genome

    async def _decode_genome(self, genome: np.ndarray) -> nx.DiGraph:
        """
        Decode genome back to graph.

        Reverses encoding.
        """
        # Assume 8x8 nodes (64 elements)
        n_nodes = 8
        adj_matrix = genome.reshape((n_nodes, n_nodes))

        # Create graph
        graph = nx.DiGraph()

        nodes = [
            "perception", "memory", "reasoning", "emotion",
            "intention", "action", "reflection", "integration"
        ]

        graph.add_nodes_from(nodes)

        # Add edges from adjacency matrix
        for i, node_i in enumerate(nodes):
            for j, node_j in enumerate(nodes):
                weight = adj_matrix[i, j]
                if weight > 0.01:  # Threshold for edge existence
                    graph.add_edge(node_i, node_j, weight=float(weight))

        return graph

    async def _genome_crossover(
        self,
        genome1: np.ndarray,
        genome2: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Perform crossover between two genomes.

        Uses single-point crossover.
        """
        crossover_point = np.random.randint(1, len(genome1))

        child1 = np.concatenate([
            genome1[:crossover_point],
            genome2[crossover_point:]
        ])

        child2 = np.concatenate([
            genome2[:crossover_point],
            genome1[crossover_point:]
        ])

        return child1, child2

    async def get_stats(self) -> Dict[str, Any]:
        """Get evolution statistics."""
        if not self.population:
            return {
                "generation": self.generation,
                "population_size": 0,
                "best_fitness": 0.0,
                "avg_fitness": 0.0
            }

        best = self._get_best_organism()
        avg_fitness = np.mean([org.fitness for org in self.population.values()])

        return {
            "generation": self.generation,
            "population_size": len(self.population),
            "best_fitness": float(best.fitness),
            "avg_fitness": float(avg_fitness),
            "best_phi": float(best.phi),
            "best_soul": float(best.soul_vector),
            "fitness_history_length": len(self.best_fitness_history)
        }
