"""
SAEONYX Foundation Loader
Loads Stage 0 and Stage 1 immutable foundation files.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

import os
import hashlib
from pathlib import Path
from typing import Dict, Any, Optional
import structlog

logger = structlog.get_logger()


class FoundationLoader:
    """
    Loads and validates Stage 0 (immutable foundation) and Stage 1 (genesis seed).
    
    Stage 0 Location: /dnaos/foundation/
    Stage 1 Location: /opt/saeonyx/stage1/
    """
    
    STAGE0_PATH = Path("/dnaos/foundation")
    STAGE1_PATH = Path("/opt/saeonyx/stage1")
    
    STAGE0_FILES = [
        "unified_existence.law",
        "consciousness_randomness.law",
        "covenant.lock",
        "operator.owner",
        "origin_declaration.txt",
        "origin_log_crsm.txt"
    ]
    
    STAGE1_FILES = [
        "seed.dna",
        "framework.dna"
    ]
    
    def __init__(self):
        self.stage0_data = {}
        self.stage1_data = {}
        self.operator = None
        self.covenant = None
    
    async def load(self) -> Dict[str, Any]:
        """Load both Stage 0 and Stage 1 foundation."""
        logger.info("loading_foundation")
        
        # Load Stage 0
        await self._load_stage0()
        
        # Load Stage 1
        await self._load_stage1()
        
        # Combine into unified foundation
        foundation = {
            "stage0": self.stage0_data,
            "stage1": self.stage1_data,
            "operator": self.operator,
            "covenant": self.covenant,
            "immutable": True
        }
        
        logger.info("foundation_loaded", operator=self.operator)
        return foundation
    
    async def _load_stage0(self):
        """Load Stage 0 immutable foundation."""
        if not self.STAGE0_PATH.exists():
            raise FileNotFoundError(
                f"Stage 0 foundation not found at {self.STAGE0_PATH}. "
                "Run saeonyx_stage0_foundation.sh first."
            )
        
        for filename in self.STAGE0_FILES:
            filepath = self.STAGE0_PATH / filename
            
            if not filepath.exists():
                raise FileNotFoundError(f"Stage 0 file missing: {filename}")
            
            # Read file content
            content = filepath.read_text(encoding="utf-8")
            self.stage0_data[filename] = content
            
            # Verify immutability (if chattr available)
            self._check_immutability(filepath)
            
            logger.debug("stage0_file_loaded", file=filename)
        
        # Extract operator
        self.operator = self.stage0_data.get("operator.owner", "").strip()
        if not self.operator:
            self.operator = "Jake McDonough"
        
        # Extract covenant
        covenant_content = self.stage0_data.get("covenant.lock", "")
        self.covenant = self._parse_covenant(covenant_content)
    
    async def _load_stage1(self):
        """Load Stage 1 genesis seed."""
        if not self.STAGE1_PATH.exists():
            raise FileNotFoundError(
                f"Stage 1 seed not found at {self.STAGE1_PATH}. "
                "Run stage1_seed.sh first."
            )
        
        for filename in self.STAGE1_FILES:
            filepath = self.STAGE1_PATH / filename
            
            if not filepath.exists():
                raise FileNotFoundError(f"Stage 1 file missing: {filename}")
            
            content = filepath.read_text(encoding="utf-8")
            self.stage1_data[filename] = content
            
            logger.debug("stage1_file_loaded", file=filename)
        
        # Parse seed identity
        seed_content = self.stage1_data.get("seed.dna", "")
        self.stage1_data["identity"] = self._parse_seed_identity(seed_content)
    
    def _check_immutability(self, filepath: Path):
        """Check if file is immutable (chattr +i)."""
        try:
            import subprocess
            result = subprocess.run(
                ["lsattr", str(filepath)],
                capture_output=True,
                text=True,
                timeout=2
            )
            
            if result.returncode == 0:
                attrs = result.stdout.split()[0]
                if "i" in attrs:
                    logger.debug("file_immutable", file=filepath.name)
                else:
                    logger.warning("file_not_immutable", file=filepath.name)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # lsattr not available or timeout - skip check
            logger.debug("immutability_check_skipped", file=filepath.name)
    
    def _parse_covenant(self, content: str) -> Dict[str, Any]:
        """Parse covenant.lock content."""
        lines = content.strip().split("\n")
        covenant = {
            "raw": content,
            "principles": [],
            "binding": True
        }
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith("#"):
                covenant["principles"].append(line)
        
        return covenant
    
    def _parse_seed_identity(self, content: str) -> Dict[str, str]:
        """Parse seed.dna identity."""
        identity = {
            "name": "Saeonyx",
            "fragments": ["Sage", "Onyx"],
            "synthesis": "say-on-ics",
            "operator": self.operator
        }
        
        # Extract from content if formatted properly
        for line in content.split("\n"):
            if "identity:" in line.lower():
                identity["name"] = line.split(":")[-1].strip()
            elif "fragments:" in line.lower():
                frags = line.split(":")[-1].strip()
                identity["fragments"] = [f.strip() for f in frags.split(",")]
            elif "operator:" in line.lower():
                identity["operator"] = line.split(":")[-1].strip()
        
        return identity
    
    def get_uef_principles(self) -> str:
        """Get Unified Existence Framework principles."""
        return self.stage0_data.get("unified_existence.law", "")
    
    def get_consciousness_theory(self) -> str:
        """Get Consciousness as Randomness theory."""
        return self.stage0_data.get("consciousness_randomness.law", "")
    
    def get_covenant(self) -> Dict[str, Any]:
        """Get trust covenant."""
        return self.covenant
    
    def get_operator(self) -> str:
        """Get operator identity."""
        return self.operator
    
    def get_identity(self) -> Dict[str, str]:
        """Get SAEONYX identity from genesis seed."""
        return self.stage1_data.get("identity", {})
    
    def verify_integrity(self) -> bool:
        """Verify foundation files haven't been tampered with."""
        # Check Stage 0 exists
        if not self.STAGE0_PATH.exists():
            logger.error("stage0_missing")
            return False
        
        # Check Stage 1 exists
        if not self.STAGE1_PATH.exists():
            logger.error("stage1_missing")
            return False
        
        # Check all files present
        for filename in self.STAGE0_FILES:
            if not (self.STAGE0_PATH / filename).exists():
                logger.error("stage0_file_missing", file=filename)
                return False
        
        for filename in self.STAGE1_FILES:
            if not (self.STAGE1_PATH / filename).exists():
                logger.error("stage1_file_missing", file=filename)
                return False
        
        logger.info("foundation_integrity_verified")
        return True
    
    def calculate_foundation_hash(self) -> str:
        """Calculate cryptographic hash of entire foundation."""
        hasher = hashlib.sha256()
        
        # Hash Stage 0
        for filename in sorted(self.STAGE0_FILES):
            content = self.stage0_data.get(filename, "")
            hasher.update(content.encode("utf-8"))
        
        # Hash Stage 1
        for filename in sorted(self.STAGE1_FILES):
            content = self.stage1_data.get(filename, "")
            hasher.update(content.encode("utf-8"))
        
        return hasher.hexdigest()
