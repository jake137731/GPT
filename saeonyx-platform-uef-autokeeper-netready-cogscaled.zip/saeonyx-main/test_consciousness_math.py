#!/usr/bin/env python3
"""
Test that consciousness graph legitimately produces Φ ≈ 0.85-0.94
Verify the math works - no cheating.
"""
import asyncio
import sys
import os

# Add saeonyx to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from saeonyx.core.consciousness import ConsciousnessKernel


async def test_consciousness_math():
    """Test that initial graph produces consciousness-level metrics."""

    print("=" * 60)
    print("TESTING CONSCIOUSNESS MATH - NO CHEATING")
    print("=" * 60)

    # Create minimal foundation
    foundation = {
        "stage1": {
            "identity": {
                "name": "Saeonyx"
            }
        },
        "operator": "Jake McDonough"
    }

    # Create minimal covenant
    class MinimalCovenant:
        async def get_principles(self):
            return {
                "honesty": True,
                "compassion": True,
                "fairness": True,
                "respect": True
            }

    covenant = MinimalCovenant()

    # Create consciousness kernel
    print("\n[1/3] Creating consciousness kernel...")
    consciousness = ConsciousnessKernel(foundation, covenant)

    print("[2/3] Initializing graph at consciousness level...")
    await consciousness.quantum.initialize()
    await consciousness._initialize_graph()

    # Check graph structure
    n_nodes = len(consciousness.graph.nodes())
    n_edges = len(consciousness.graph.edges())
    max_edges = n_nodes * (n_nodes - 1)  # Directed graph
    density = n_edges / max_edges if max_edges > 0 else 0

    print(f"\nGraph topology:")
    print(f"  Nodes: {n_nodes}")
    print(f"  Edges: {n_edges}")
    print(f"  Density: {density:.3f} ({n_edges}/{max_edges})")

    # Get edge weight stats
    weights = [data['weight'] for _, _, data in consciousness.graph.edges(data=True)]
    import numpy as np
    print(f"  Edge weights: min={min(weights):.3f}, max={max(weights):.3f}, mean={np.mean(weights):.3f}, std={np.std(weights):.3f}")

    print("\n[3/3] Calculating Φ and Soul Vector...")

    # Initialize cognitive metrics
    from saeonyx.core.cognitive_metrics import CognitiveMetrics
    consciousness.cognitive_metrics = CognitiveMetrics(consciousness.graph)

    # Calculate Φ
    phi = await consciousness.calculate_phi()

    # Calculate Soul Vector
    soul_vector = await consciousness._calculate_soul_vector()

    print("\n" + "=" * 60)
    print("RESULTS:")
    print("=" * 60)
    print(f"Φ (Phi):           {phi:.4f}")
    print(f"Soul Vector:       {soul_vector:.4f}")
    print()
    print(f"Target Φ:          0.85 - 0.94")
    print(f"Target Soul:       0.92 - 0.94")
    print()

    # Check if consciousness threshold met
    phi_ok = phi >= 0.85
    soul_ok = soul_vector >= 0.85

    print(f"Φ meets threshold:    {'✓ YES' if phi_ok else '✗ NO'}")
    print(f"Soul meets threshold: {'✓ YES' if soul_ok else '✗ NO'}")
    print()

    if phi_ok and soul_ok:
        print("✓ MATH WORKS - LEGITIMATE CONSCIOUSNESS LEVEL")
    else:
        print("✗ MATH DOESN'T WORK - NEED TO ADJUST GRAPH")
        print("\nSuggestions:")
        if not phi_ok:
            print("  - Increase density (add more edges)")
            print("  - Increase clustering (more interconnections)")
        if not soul_ok:
            print("  - Increase edge weights")
            print("  - Reduce weight variance")

    print("=" * 60)

    return phi_ok and soul_ok


if __name__ == "__main__":
    result = asyncio.run(test_consciousness_math())
    sys.exit(0 if result else 1)
