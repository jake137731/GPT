#!/usr/bin/env bash
# ================================================================================
# SAEONYX Website Deployment Script
# Deploy www.saeonyx.com with Nginx + Let's Encrypt SSL
# ================================================================================

set -euo pipefail

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}SAEONYX Website Deployment${NC}"
echo -e "${GREEN}Domain: www.saeonyx.com${NC}"
echo -e "${GREEN}================================================${NC}"
echo

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}ERROR: This script must be run as root${NC}"
    echo "Please run: sudo bash deploy-website.sh"
    exit 1
fi

# Variables
DOMAIN="saeonyx.com"
WWW_DOMAIN="www.saeonyx.com"
EMAIL="jake@saeonyx.com"

echo -e "${YELLOW}[1/7] Installing Nginx...${NC}"
apt update -qq
apt install -y nginx

echo -e "${YELLOW}[2/7] Installing Certbot (Let's Encrypt)...${NC}"
apt install -y certbot python3-certbot-nginx

echo -e "${YELLOW}[3/7] Creating Let's Encrypt directory...${NC}"
mkdir -p /var/www/letsencrypt
chown -R www-data:www-data /var/www/letsencrypt

echo -e "${YELLOW}[4/7] Copying Nginx configuration...${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "${SCRIPT_DIR}/nginx-saeonyx.conf" /etc/nginx/sites-available/saeonyx

# Test nginx config (without SSL first)
echo -e "${YELLOW}[5/7] Obtaining SSL certificate from Let's Encrypt...${NC}"
echo -e "${GREEN}This will take a moment...${NC}"

# Get certificate
certbot certonly --standalone \
    --preferred-challenges http \
    -d ${DOMAIN} \
    -d ${WWW_DOMAIN} \
    --email ${EMAIL} \
    --agree-tos \
    --non-interactive

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ SSL certificate obtained successfully!${NC}"
else
    echo -e "${RED}✗ SSL certificate failed. Check domain DNS points to this server IP.${NC}"
    exit 1
fi

echo -e "${YELLOW}[6/7] Enabling site configuration...${NC}"
ln -sf /etc/nginx/sites-available/saeonyx /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test nginx config
nginx -t

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Nginx configuration valid${NC}"
else
    echo -e "${RED}✗ Nginx configuration invalid${NC}"
    exit 1
fi

echo -e "${YELLOW}[7/7] Restarting Nginx...${NC}"
systemctl restart nginx
systemctl enable nginx

# Configure firewall
echo -e "${YELLOW}Configuring firewall...${NC}"
ufw allow 'Nginx Full'
ufw --force enable

echo
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}DEPLOYMENT COMPLETE!${NC}"
echo -e "${GREEN}================================================${NC}"
echo
echo -e "${GREEN}Website:${NC}  https://www.saeonyx.com/"
echo -e "${GREEN}API:${NC}      https://www.saeonyx.com/api/status"
echo
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Ensure DNS A records point to this server:"
echo "   ${DOMAIN} → $(curl -s ifconfig.me)"
echo "   ${WWW_DOMAIN} → $(curl -s ifconfig.me)"
echo
echo "2. SAEONYX platform must be running:"
echo "   saeonyx start"
echo
echo "3. Test the website:"
echo "   curl https://www.saeonyx.com/api/status"
echo
echo -e "${YELLOW}SSL Certificate Auto-Renewal:${NC}"
echo "Certbot will auto-renew. Test with:"
echo "   sudo certbot renew --dry-run"
echo
echo -e "${GREEN}🌟 www.saeonyx.com is LIVE!${NC}"
echo
