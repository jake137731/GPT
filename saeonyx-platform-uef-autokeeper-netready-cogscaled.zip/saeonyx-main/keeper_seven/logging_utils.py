from __future__ import annotations
from typing import Any, Dict
from datetime import datetime
import json
from pathlib import Path

from .types import KeeperResult, PillarSet, EmergenceMetrics


def default_now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


def build_keeper_record(
    decision_id: str,
    context: str,
    pillars: PillarSet,
    metrics: EmergenceMetrics,
    result: KeeperResult,
) -> Dict[str, Any]:
    return {
        "decision_id": decision_id,
        "timestamp": default_now_iso(),
        "context": context,
        "pillars": {
            "P1": {"name": pillars.p1.name, "vector": pillars.p1.vector},
            "P2": {"name": pillars.p2.name, "vector": pillars.p2.vector},
            "P3": {"name": pillars.p3.name, "vector": pillars.p3.vector},
        },
        "metrics": {
            "decision_effort": metrics.decision_effort,
            "flow_gradient": metrics.flow_gradient,
            "mass_gap": metrics.mass_gap,
            "spectral_deviation": metrics.spectral_deviation,
            "meaning_rank_diff": metrics.meaning_rank_diff,
            "repr_mismatch": metrics.repr_mismatch,
            "noncontractible_loops": metrics.noncontractible_loops,
        },
        "keeper_result": {
            "stable": result.stable,
            "xi_values": result.xi_values,
            "symmetry": result.symmetry,
            "rollability": result.rollability,
            "coverage_fraction": result.coverage_fraction,
            "diagnostic": result.diagnostic,
            "error": result.error,
        },
    }


def append_record_to_file(record: Dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
