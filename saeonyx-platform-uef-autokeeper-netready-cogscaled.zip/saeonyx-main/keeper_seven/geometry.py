from __future__ import annotations
from typing import Dict, Tuple
from .types import PillarSet, Vector


def _l2_norm(v: Vector) -> float:
    return sum(x * x for x in v) ** 0.5


def _vector_distance(a: Vector, b: Vector) -> float:
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    return _l2_norm([x - y for x, y in zip(a, b)])


def compute_symmetry(pillars: PillarSet) -> Tuple[float, Dict[str, float]]:
    p1, p2, p3 = pillars.p1.vector, pillars.p2.vector, pillars.p3.vector

    d12 = _vector_distance(p1, p2)
    d23 = _vector_distance(p2, p3)
    d31 = _vector_distance(p3, p1)

    distances = {"P1_P2": d12, "P2_P3": d23, "P3_P1": d31}

    avg = (d12 + d23 + d31) / 3.0
    var = ((d12 - avg) ** 2 + (d23 - avg) ** 2 + (d31 - avg) ** 2) / 3.0

    symmetry = 1.0 / (1.0 + var)
    return symmetry, distances


def compute_coverage_fraction(
    consider_p1: bool = True,
    consider_p2: bool = True,
    consider_p3: bool = True,
) -> float:
    count = int(consider_p1) + int(consider_p2) + int(consider_p3)
    return count / 3.0
