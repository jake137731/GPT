from __future__ import annotations
from dataclasses import dataclass


@dataclass
class KeeperConfig:
    """Configuration for Keeper of Seven thresholds and behavior."""

    symmetry_min: float = 0.7
    rollability_min: float = 0.7
    xi_max_abs: float = 1e-3
    require_all_pillars: bool = True
