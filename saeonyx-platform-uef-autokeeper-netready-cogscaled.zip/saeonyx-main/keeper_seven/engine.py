from __future__ import annotations
from typing import Dict, Any

from .types import PillarSet, EmergenceMetrics, KeeperResult
from .geometry import compute_symmetry, compute_coverage_fraction
from .xi_modes import compute_all_xi
from .config import KeeperConfig


def compute_rollability(symmetry: float, coverage_fraction: float) -> float:
    if coverage_fraction < 1.0:
        return 0.0
    return symmetry


def keeper_of_seven(
    pillars: PillarSet,
    metrics: EmergenceMetrics,
    cfg: KeeperConfig | None = None,
    consider_p1: bool = True,
    consider_p2: bool = True,
    consider_p3: bool = True,
) -> KeeperResult:
    if cfg is None:
        cfg = KeeperConfig()

    symmetry, distances = compute_symmetry(pillars)
    coverage_fraction = compute_coverage_fraction(consider_p1, consider_p2, consider_p3)
    roll = compute_rollability(symmetry, coverage_fraction)
    xi_values = compute_all_xi(metrics)

    all_xi_ok = all(abs(v) <= cfg.xi_max_abs for v in xi_values.values())
    symmetry_ok = symmetry >= cfg.symmetry_min
    roll_ok = roll >= cfg.rollability_min

    stable = all_xi_ok and symmetry_ok and roll_ok and (
        (not cfg.require_all_pillars) or coverage_fraction >= 1.0
    )

    diagnostic: Dict[str, Any] = {
        "distances": distances,
        "symmetry_ok": symmetry_ok,
        "rollability_ok": roll_ok,
        "all_xi_ok": all_xi_ok,
        "symmetry_min": cfg.symmetry_min,
        "rollability_min": cfg.rollability_min,
        "xi_max_abs": cfg.xi_max_abs,
    }

    return KeeperResult(
        stable=stable,
        xi_values=xi_values,
        symmetry=symmetry,
        rollability=roll,
        coverage_fraction=coverage_fraction,
        diagnostic=diagnostic,
        error=None if stable else "KEEPER_OF_SEVEN_VIOLATION",
    )


def evaluate_decision(
    decision_id: str,
    pillars: PillarSet,
    metrics: EmergenceMetrics,
    cfg: KeeperConfig | None = None,
) -> KeeperResult:
    return keeper_of_seven(pillars=pillars, metrics=metrics, cfg=cfg)
