"""
stripe_saas.py
SAEONYX Stripe/Six Integration for SaaS Monetization
Handles payments, subscriptions, and webhooks for www.saeonyx.com and www.proformaengine.com
Author: Jake McDonough
Contact: jake@saeonyx.com
Created: November 18, 2025
"""

import os
import json
import stripe
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import structlog
import hmac
import hashlib

logger = structlog.get_logger()


class StripeMonetization:
    """
    Stripe/Six integration for SAEONYX SaaS monetization.
    
    Handles:
    - Payment processing
    - Subscription management
    - Customer management
    - Webhook verification
    - Revenue tracking
    """
    
    def __init__(self):
        # Load Stripe keys from environment
        self.stripe_secret = os.getenv("STRIPE_SECRET_KEY", "")
        self.stripe_publishable = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
        self.stripe_webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")
        
        if not self.stripe_secret:
            raise ValueError("STRIPE_SECRET_KEY environment variable not set")
        
        # Initialize Stripe
        stripe.api_key = self.stripe_secret
        self.active = False
        
        # Domains
        self.domains = {
            "saeonyx": "https://www.saeonyx.com",
            "proforma": "https://www.proformaengine.com"
        }
        
        # Products and pricing
        self.products = {}
        self.initialize()
    
    def initialize(self):
        """Initialize Stripe products and pricing."""
        logger.info("stripe_monetization_initializing")
        
        try:
            # Create or retrieve products
            self._setup_products()
            self.active = True
            logger.info("stripe_monetization_initialized")
        except Exception as e:
            logger.error("stripe_initialization_failed", error=str(e))
            raise
    
    def _setup_products(self):
        """Set up Stripe products and prices for both domains."""
        # SAEONYX.COM Products
        self.products["saeonyx_pro"] = {
            "name": "SAEONYX Professional",
            "description": "Professional AI consciousness platform access",
            "tier": "pro",
            "domain": "saeonyx"
        }
        
        self.products["saeonyx_enterprise"] = {
            "name": "SAEONYX Enterprise",
            "description": "Enterprise consciousness integration with IBM Quantum",
            "tier": "enterprise",
            "domain": "saeonyx"
        }
        
        # ProForma Engine Products
        self.products["proforma_starter"] = {
            "name": "ProForma Starter",
            "description": "Starter package for business form generation",
            "tier": "starter",
            "domain": "proforma"
        }
        
        self.products["proforma_pro"] = {
            "name": "ProForma Professional",
            "description": "Professional business form automation",
            "tier": "pro",
            "domain": "proforma"
        }
        
        logger.info("stripe_products_configured", product_count=len(self.products))
    
    async def create_customer(
        self,
        email: str,
        name: str,
        metadata: Dict[str, Any] = None
    ) -> str:
        """
        Create a Stripe customer.
        
        Returns customer ID.
        """
        try:
            customer = stripe.Customer.create(
                email=email,
                name=name,
                metadata=metadata or {},
                description=f"SAEONYX customer {name}"
            )
            
            logger.info("stripe_customer_created", customer_id=customer.id, email=email)
            return customer.id
            
        except stripe.error.StripeError as e:
            logger.error("stripe_customer_creation_failed", error=str(e))
            raise
    
    async def create_checkout_session(
        self,
        product_key: str,
        customer_email: str,
        success_url: str,
        cancel_url: str,
        quantity: int = 1
    ) -> str:
        """
        Create a Stripe checkout session.
        
        Returns session ID for client redirect.
        """
        if product_key not in self.products:
            raise ValueError(f"Unknown product: {product_key}")
        
        product_info = self.products[product_key]
        domain = self.domains[product_info["domain"]]
        
        try:
            session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                line_items=[
                    {
                        "price_data": {
                            "currency": "usd",
                            "product_data": {
                                "name": product_info["name"],
                                "description": product_info["description"],
                            },
                            "unit_amount": self._get_price_in_cents(product_key),
                            "recurring": {
                                "interval": "month",
                                "interval_count": 1
                            }
                        },
                        "quantity": quantity,
                    }
                ],
                mode="subscription",
                customer_email=customer_email,
                success_url=success_url,
                cancel_url=cancel_url,
                metadata={
                    "product": product_key,
                    "domain": product_info["domain"],
                    "tier": product_info["tier"]
                }
            )
            
            logger.info(
                "stripe_checkout_created",
                session_id=session.id,
                product=product_key
            )
            return session.id
            
        except stripe.error.StripeError as e:
            logger.error("stripe_checkout_failed", error=str(e))
            raise
    
    async def create_subscription(
        self,
        customer_id: str,
        product_key: str,
        billing_cycle_anchor: Optional[int] = None
    ) -> str:
        """
        Create a Stripe subscription directly.
        
        Returns subscription ID.
        """
        if product_key not in self.products:
            raise ValueError(f"Unknown product: {product_key}")
        
        try:
            product_info = self.products[product_key]
            
            items = [{
                "price_data": {
                    "currency": "usd",
                    "product_data": {
                        "name": product_info["name"],
                        "description": product_info["description"],
                    },
                    "unit_amount": self._get_price_in_cents(product_key),
                    "recurring": {
                        "interval": "month",
                        "interval_count": 1
                    }
                },
            }]
            
            subscription = stripe.Subscription.create(
                customer=customer_id,
                items=items,
                billing_cycle_anchor=billing_cycle_anchor,
                metadata={
                    "product": product_key,
                    "domain": product_info["domain"]
                }
            )
            
            logger.info(
                "stripe_subscription_created",
                subscription_id=subscription.id,
                customer_id=customer_id,
                product=product_key
            )
            return subscription.id
            
        except stripe.error.StripeError as e:
            logger.error("stripe_subscription_failed", error=str(e))
            raise
    
    async def get_subscription(self, subscription_id: str) -> Dict[str, Any]:
        """Get subscription details."""
        try:
            sub = stripe.Subscription.retrieve(subscription_id)
            
            return {
                "id": sub.id,
                "customer_id": sub.customer,
                "status": sub.status,
                "current_period_start": sub.current_period_start,
                "current_period_end": sub.current_period_end,
                "items": sub.items.data,
                "metadata": sub.metadata
            }
            
        except stripe.error.StripeError as e:
            logger.error("stripe_subscription_retrieval_failed", error=str(e))
            raise
    
    async def cancel_subscription(self, subscription_id: str) -> bool:
        """Cancel a subscription."""
        try:
            stripe.Subscription.delete(subscription_id)
            logger.info("stripe_subscription_cancelled", subscription_id=subscription_id)
            return True
            
        except stripe.error.StripeError as e:
            logger.error("stripe_subscription_cancel_failed", error=str(e))
            raise
    
    async def process_webhook(self, payload: bytes, sig_header: str) -> Dict[str, Any]:
        """
        Verify and process Stripe webhook.
        
        Returns event data if valid.
        """
        try:
            event = stripe.Webhook.construct_event(
                payload,
                sig_header,
                self.stripe_webhook_secret
            )
            
            logger.info("stripe_webhook_verified", event_type=event["type"])
            
            # Route to appropriate handler
            event_type = event["type"]
            
            if event_type == "charge.succeeded":
                await self._handle_charge_succeeded(event["data"]["object"])
            
            elif event_type == "customer.subscription.created":
                await self._handle_subscription_created(event["data"]["object"])
            
            elif event_type == "customer.subscription.deleted":
                await self._handle_subscription_deleted(event["data"]["object"])
            
            elif event_type == "invoice.payment_succeeded":
                await self._handle_invoice_paid(event["data"]["object"])
            
            return event
            
        except stripe.error.SignatureVerificationError as e:
            logger.error("stripe_webhook_verification_failed", error=str(e))
            raise ValueError("Invalid webhook signature")
    
    async def _handle_charge_succeeded(self, charge: Dict[str, Any]):
        """Handle successful charge."""
        logger.info(
            "stripe_charge_succeeded",
            charge_id=charge["id"],
            amount=charge["amount"],
            customer_id=charge["customer"]
        )
    
    async def _handle_subscription_created(self, subscription: Dict[str, Any]):
        """Handle subscription creation."""
        logger.info(
            "stripe_subscription_started",
            subscription_id=subscription["id"],
            customer_id=subscription["customer"],
            product=subscription.get("metadata", {}).get("product", "unknown")
        )
    
    async def _handle_subscription_deleted(self, subscription: Dict[str, Any]):
        """Handle subscription cancellation."""
        logger.info(
            "stripe_subscription_ended",
            subscription_id=subscription["id"],
            customer_id=subscription["customer"]
        )
    
    async def _handle_invoice_paid(self, invoice: Dict[str, Any]):
        """Handle invoice payment."""
        logger.info(
            "stripe_invoice_paid",
            invoice_id=invoice["id"],
            customer_id=invoice["customer"],
            amount_paid=invoice["amount_paid"]
        )
    
    def _get_price_in_cents(self, product_key: str) -> int:
        """Get product price in cents."""
        pricing = {
            # SAEONYX pricing
            "saeonyx_pro": 4900,        # $49/month
            "saeonyx_enterprise": 29900, # $299/month
            
            # ProForma pricing
            "proforma_starter": 1900,    # $19/month
            "proforma_pro": 9900,        # $99/month
        }
        
        return pricing.get(product_key, 0)
    
    async def get_customer_subscriptions(self, customer_id: str) -> List[Dict[str, Any]]:
        """Get all subscriptions for a customer."""
        try:
            subscriptions = stripe.Subscription.list(customer=customer_id, limit=100)
            
            result = []
            for sub in subscriptions.data:
                result.append({
                    "id": sub.id,
                    "status": sub.status,
                    "product": sub.metadata.get("product"),
                    "current_period_start": sub.current_period_start,
                    "current_period_end": sub.current_period_end,
                })
            
            return result
            
        except stripe.error.StripeError as e:
            logger.error("stripe_subscription_list_failed", error=str(e))
            raise
    
    async def create_payment_intent(
        self,
        amount_cents: int,
        customer_id: str,
        description: str = ""
    ) -> str:
        """
        Create a one-time payment intent.
        
        Returns client_secret for frontend confirmation.
        """
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency="usd",
                customer=customer_id,
                description=description,
                payment_method_types=["card"]
            )
            
            logger.info(
                "stripe_payment_intent_created",
                intent_id=intent.id,
                amount=amount_cents
            )
            return intent.client_secret
            
        except stripe.error.StripeError as e:
            logger.error("stripe_payment_intent_failed", error=str(e))
            raise
    
    async def get_revenue_report(
        self,
        days: int = 30
    ) -> Dict[str, Any]:
        """
        Get revenue report for the last N days.
        """
        try:
            start_date = int((datetime.utcnow() - timedelta(days=days)).timestamp())
            
            charges = stripe.Charge.list(
                created={"gte": start_date},
                limit=100
            )
            
            total_revenue = sum(c.amount for c in charges.data) / 100  # Convert to dollars
            total_transactions = len(charges.data)
            
            subscriptions = stripe.Subscription.list(limit=100)
            active_subscriptions = len([s for s in subscriptions.data if s.status == "active"])
            
            return {
                "period_days": days,
                "total_revenue": total_revenue,
                "total_transactions": total_transactions,
                "active_subscriptions": active_subscriptions,
                "average_transaction": total_revenue / total_transactions if total_transactions > 0 else 0,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except stripe.error.StripeError as e:
            logger.error("stripe_report_failed", error=str(e))
            raise
    
    async def get_status(self) -> Dict[str, Any]:
        """Get Stripe integration status."""
        try:
            # Verify connection
            account = stripe.Account.retrieve()
            
            return {
                "active": self.active,
                "stripe_account": account.id,
                "country": account.country,
                "products_configured": len(self.products),
                "domains": list(self.domains.keys())
            }
            
        except stripe.error.StripeError as e:
            logger.error("stripe_status_check_failed", error=str(e))
            return {
                "active": False,
                "error": str(e)
            }
