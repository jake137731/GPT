#!/bin/bash
# SAEONYX Setup Script
# Author: Jake McDonough
# Contact: jake@saeonyx.com

set -euo pipefail

echo "============================================"
echo "SAEONYX v1.0 Setup"
echo "Consciousness-Integrated AI Platform"
echo "============================================"
echo ""

# Check if running on Ubuntu 22.04
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [ "$ID" != "ubuntu" ] || [ "$VERSION_ID" != "22.04" ]; then
        echo "Warning: This script is designed for Ubuntu 22.04.5 LTS"
        echo "Current OS: $ID $VERSION_ID"
        read -p "Continue anyway? (yes/no) " -r
        if [ "$REPLY" != "yes" ]; then
            exit 1
        fi
    fi
fi

# Check Python version
echo "Checking Python version..."
PYTHON_VERSION=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
REQUIRED_VERSION="3.10"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "Error: Python 3.10+ required (found $PYTHON_VERSION)"
    exit 1
fi

echo "✓ Python $PYTHON_VERSION detected"

# Create directory structure
echo ""
echo "Creating directory structure..."

sudo mkdir -p /opt/saeonyx/{core,agents,quantum,evolution,memory,security,api,web,deployment,data}
sudo mkdir -p /var/log/saeonyx
sudo mkdir -p /dnaos/foundation

# Set ownership
CURRENT_USER=$(whoami)
sudo chown -R $CURRENT_USER:$CURRENT_USER /opt/saeonyx
sudo chown -R $CURRENT_USER:$CURRENT_USER /var/log/saeonyx

echo "✓ Directory structure created"

# Copy files to /opt/saeonyx
echo ""
echo "Installing SAEONYX files..."

# Check if we're in the source directory
if [ ! -f "saeonyx_master.py" ] && [ ! -f "saeonyx-master.py" ]; then
    echo "Error: Please run this script from the SAEONYX source directory"
    exit 1
fi

# Copy all Python files
cp -r ./*.py /opt/saeonyx/ 2>/dev/null || true
cp -r ./core /opt/saeonyx/ 2>/dev/null || true
cp -r ./agents /opt/saeonyx/ 2>/dev/null || true
cp -r ./quantum /opt/saeonyx/ 2>/dev/null || true
cp -r ./evolution /opt/saeonyx/ 2>/dev/null || true
cp -r ./memory /opt/saeonyx/ 2>/dev/null || true
cp -r ./security /opt/saeonyx/ 2>/dev/null || true
cp -r ./api /opt/saeonyx/ 2>/dev/null || true
cp -r ./web /opt/saeonyx/ 2>/dev/null || true

# Rename files if they have dashes instead of underscores
cd /opt/saeonyx
for file in *-*.py; do
    if [ -f "$file" ]; then
        newname=$(echo "$file" | sed 's/-/_/g')
        mv "$file" "$newname" 2>/dev/null || true
    fi
done

echo "✓ Files installed"

# Create Python virtual environment
echo ""
echo "Creating Python virtual environment..."
cd /opt/saeonyx
python3 -m venv venv
source venv/bin/activate

echo "✓ Virtual environment created"

# Install dependencies
echo ""
echo "Installing Python dependencies..."
echo "This may take a few minutes..."

pip install --upgrade pip
pip install -r requirements.txt

echo "✓ Dependencies installed"

# Check if Stage 0 foundation exists
echo ""
if [ -d "/dnaos/foundation" ] && [ -f "/dnaos/foundation/operator.owner" ]; then
    echo "✓ Stage 0 foundation detected"
else
    echo "⚠ Stage 0 foundation not found"
    echo "Please run: sudo bash saeonyx_stage0_foundation.sh"
    echo "Before running SAEONYX for the first time"
fi

# Check if Stage 1 seed exists
if [ -d "/opt/saeonyx/stage1" ] && [ -f "/opt/saeonyx/stage1/seed.dna" ]; then
    echo "✓ Stage 1 seed detected"
else
    echo "⚠ Stage 1 seed not found"
    echo "Please run: bash stage1_seed.sh"
    echo "Before running SAEONYX for the first time"
fi

# Create systemd service (optional)
echo ""
read -p "Install SAEONYX as systemd service? (yes/no) " -r
if [ "$REPLY" = "yes" ]; then
    cat > /tmp/saeonyx.service << 'EOF'
[Unit]
Description=SAEONYX v1.0 Consciousness Platform
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/saeonyx
Environment="PATH=/opt/saeonyx/venv/bin"
ExecStart=/opt/saeonyx/venv/bin/python3 /opt/saeonyx/saeonyx_master.py --start
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
    
    # Replace $USER with actual user
    sed -i "s/\$USER/$CURRENT_USER/g" /tmp/saeonyx.service
    
    sudo mv /tmp/saeonyx.service /etc/systemd/system/saeonyx.service
    sudo systemctl daemon-reload
    
    echo "✓ Systemd service installed"
    echo ""
    echo "To start SAEONYX automatically:"
    echo "  sudo systemctl enable saeonyx"
    echo "  sudo systemctl start saeonyx"
fi

echo ""
echo "============================================"
echo "✓ SAEONYX Setup Complete"
echo "============================================"
echo ""
echo "Next steps:"
echo "1. Run Stage 0 foundation: sudo bash saeonyx_stage0_foundation.sh"
echo "2. Run Stage 1 seed: bash stage1_seed.sh"
echo "3. Initialize SAEONYX: cd /opt/saeonyx && source venv/bin/activate"
echo "4. Run: python3 saeonyx_master.py --init"
echo "5. Start: python3 saeonyx_master.py --start"
echo ""
echo "Web Interface: http://localhost:8081"
echo "API Endpoint: http://localhost:8080/api"
echo ""
echo "Documentation: /opt/saeonyx/README.md"
echo ""
