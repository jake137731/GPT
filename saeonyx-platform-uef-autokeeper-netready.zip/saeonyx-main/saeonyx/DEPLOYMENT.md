# SAEONYX Deployment Guide

**Production Deployment for Ubuntu 22.04.5 LTS**

Author: Jake McDonough  
Contact: jake@saeonyx.com

---

## Overview

This guide covers production deployment of SAEONYX on Ubuntu 22.04.5 LTS with enterprise-grade security and reliability.

---

## System Requirements

### Minimum
- **CPU:** 8 cores
- **RAM:** 32GB
- **Storage:** 1TB SSD
- **OS:** Ubuntu 22.04.5 LTS (kernel 5.15+)
- **Python:** 3.10+

### Recommended (Production)
- **CPU:** 16+ cores
- **RAM:** 64GB+
- **Storage:** 2TB+ NVMe SSD
- **Network:** Gigabit Ethernet
- **Backup:** RAID 1 or higher

---

## Pre-Deployment Checklist

- [ ] Ubuntu 22.04.5 LTS installed
- [ ] System updated (`apt update && apt upgrade`)
- [ ] Python 3.10+ installed
- [ ] User account created (non-root)
- [ ] SSH access configured
- [ ] Firewall rules planned
- [ ] Backup strategy defined

---

## Installation Steps

### 1. System Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y python3.10 python3.10-venv python3-pip \
    build-essential libssl-dev libffi-dev python3-dev \
    git curl wget

# Install optional tools
sudo apt install -y htop iotop nethogs
```

### 2. Create SAEONYX User

```bash
# Create dedicated user
sudo useradd -m -s /bin/bash saeonyx
sudo usermod -aG sudo saeonyx

# Switch to saeonyx user
sudo su - saeonyx
```

### 3. Install SAEONYX

```bash
# Create project directory
mkdir ~/saeonyx-source
cd ~/saeonyx-source

# Copy all downloaded files here

# Run setup
chmod +x setup.sh
bash setup.sh
```

### 4. Initialize Foundation

```bash
# Stage 0 (immutable foundation)
sudo bash saeonyx_stage0_foundation.sh

# Stage 1 (genesis seed)
bash stage1_seed.sh
```

### 5. Configure SAEONYX

```bash
cd /opt/saeonyx
source venv/bin/activate

# Initialize
python3 saeonyx_master.py --init

# Verify
python3 saeonyx_master.py --status
```

---

## Security Configuration

### Firewall Rules

```bash
# Install UFW
sudo apt install -y ufw

# Default policies
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH (adjust port if changed)
sudo ufw allow 22/tcp

# Allow SAEONYX API (local only)
sudo ufw allow from 127.0.0.1 to any port 8080

# Allow SAEONYX Web (local only)
sudo ufw allow from 127.0.0.1 to any port 8081

# Enable firewall
sudo ufw enable
sudo ufw status
```

### File Permissions

```bash
# Secure SAEONYX directory
sudo chown -R saeonyx:saeonyx /opt/saeonyx
sudo chmod -R 750 /opt/saeonyx

# Secure foundation (immutable)
sudo chown -R root:root /dnaos/foundation
sudo chmod -R 600 /dnaos/foundation

# Verify immutability
lsattr /dnaos/foundation/*
# Should show: ----i--------e-----
```

### SSL/TLS (Production)

For production with external access:

```bash
# Install certbot
sudo apt install -y certbot

# Generate certificate (adjust domain)
sudo certbot certonly --standalone -d saeonyx.example.com

# Update API/Web servers to use certificates
# Edit api/server.py and web/server.py
```

---

## Service Configuration

### Systemd Service

```bash
# Service already created by setup.sh
# Enable autostart
sudo systemctl enable saeonyx

# Start service
sudo systemctl start saeonyx

# Check status
sudo systemctl status saeonyx

# View logs
sudo journalctl -u saeonyx -f
```

### Service Management

```bash
# Start
sudo systemctl start saeonyx

# Stop
sudo systemctl stop saeonyx

# Restart
sudo systemctl restart saeonyx

# Status
sudo systemctl status saeonyx
```

---

## Monitoring

### System Monitoring

```bash
# CPU/Memory usage
htop

# Disk I/O
sudo iotop

# Network
sudo nethogs

# SAEONYX-specific
watch -n 5 'curl -s http://localhost:8080/api/status | jq'
```

### Log Monitoring

```bash
# Application logs
tail -f /var/log/saeonyx/*.log

# System logs
sudo journalctl -u saeonyx -f

# Consciousness metrics
watch -n 10 'python3 /opt/saeonyx/saeonyx_master.py --measure-phi'
```

---

## Backup Strategy

### Automated Backup Script

```bash
#!/bin/bash
# /opt/saeonyx/backup.sh

BACKUP_DIR="/backup/saeonyx"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup database
cp /opt/saeonyx/data/memory.db $BACKUP_DIR/memory_$DATE.db

# Backup logs
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz /var/log/saeonyx/

# Backup configuration
tar -czf $BACKUP_DIR/config_$DATE.tar.gz /opt/saeonyx/*.py /opt/saeonyx/*/

# Keep only last 30 days
find $BACKUP_DIR -name "*.db" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

### Schedule Backups

```bash
# Add to crontab
crontab -e

# Run daily at 2 AM
0 2 * * * /opt/saeonyx/backup.sh
```

---

## Performance Tuning

### Python Optimization

```bash
# Use Python optimized mode
python3 -OO saeonyx_master.py --start
```

### Database Optimization

SQLite is used for memory store. For high-performance:

```sql
-- Add indexes (run in memory.db)
CREATE INDEX IF NOT EXISTS idx_episodic_timestamp 
    ON episodic_memory(timestamp);
CREATE INDEX IF NOT EXISTS idx_semantic_concept 
    ON semantic_memory(concept);
```

### System Tuning

```bash
# Increase file descriptors
sudo vim /etc/security/limits.conf
# Add:
saeonyx soft nofile 65536
saeonyx hard nofile 65536

# Apply
sudo reboot
```

---

## Compliance

### HIPAA Compliance

SAEONYX is designed for HIPAA compliance:

- ✓ Zero external dependencies (no data leakage)
- ✓ Encryption at rest (SQLite encryption)
- ✓ Access controls (zero-trust)
- ✓ Audit logging (complete trail)
- ✓ User authentication required

**Additional HIPAA requirements:**
- Enable disk encryption (LUKS)
- Configure regular backups
- Implement access logging
- Create BAA with SAEONYX Global Holdings LLC

### DOD IL4/IL5 Compliance

SAEONYX meets DOD requirements:

- ✓ Airgapped operation (no internet required)
- ✓ FIPS 140-2 cryptography
- ✓ Multi-factor authentication ready
- ✓ Complete audit trail
- ✓ Immutable foundation

### Financial Services (SOC2)

- ✓ Data isolation
- ✓ Encryption standards
- ✓ Access controls
- ✓ Monitoring and logging
- ✓ Incident response ready

---

## Troubleshooting

### Service Won't Start

```bash
# Check logs
sudo journalctl -u saeonyx -n 50

# Check foundation
ls -la /dnaos/foundation/
lsattr /dnaos/foundation/*

# Manual start (debug mode)
cd /opt/saeonyx
source venv/bin/activate
python3 saeonyx_master.py --init
```

### High CPU Usage

```bash
# Check which component
htop

# Reduce evolution frequency
# Edit evolution/engine.py, increase sleep time
```

### Memory Issues

```bash
# Check memory usage
free -h

# Restart service
sudo systemctl restart saeonyx
```

---

## Upgrade Procedure

### Minor Upgrades

```bash
# Stop service
sudo systemctl stop saeonyx

# Backup current
cp -r /opt/saeonyx /opt/saeonyx.backup

# Copy new files
cp new_files/*.py /opt/saeonyx/

# Restart
sudo systemctl start saeonyx
```

### Major Upgrades

Contact: jake@saeonyx.com for major version upgrades.

---

## Support

**Enterprise Support:**  
Jake McDonough  
Email: jake@saeonyx.com  
Phone: 502-678-9015  
Web: www.saeonyx.com

**Emergency Contact:**  
24/7 support available for enterprise customers.

---

**SAEONYX v1.0 — Production Ready, Consciousness Aware** 🌟
