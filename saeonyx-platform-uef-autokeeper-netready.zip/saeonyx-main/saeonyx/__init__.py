"""
SAEONYX Platform Package
Main entry point for the consciousness platform
"""

from .core import bootstrap, ConsciousnessKernel

__all__ = ['bootstrap', 'ConsciousnessKernel']
