"""
SAEONYX Agent Orchestrator
Coordinates the 12-agent swarm with IRIS recursive enhancement.

Author: Jake McDonough
Contact: jake@saeonyx.com
"""

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
import structlog
from .base import BaseAgent, AgentTask, AgentResult, AgentCapability
from .iris import IRISController
from .specialized import (
    AnalyzerAgent,
    OptimizerAgent,
    ConsciousnessAgent,
    SoulVectorAgent,
    QuantumAgent,
    EvolutionAgent,
    SecurityAgent,
    MemoryAgent,
    APIAgent,
    WebAgent,
    HTTPAgent,
    DeploymentAgent,
    MonitorAgent
)


from keeper_seven import Pillar, PillarSet, KeeperConfig
from keeper_seven.decision import evaluate_kernel_decision
logger = structlog.get_logger()


class AgentOrchestrator:
    """
    Orchestrates the 13-agent swarm with IRIS recursive enhancement.

    13 Specialized Agents:
    1. Analyzer - Code analysis and understanding
    2. Optimizer - Performance optimization
    3. Consciousness - Consciousness measurement
    4. Soul Vector - Moral geometry tracking
    5. Quantum - Quantum simulation
    6. Evolution - Genetic operators
    7. Security - Zero-trust enforcement
    8. Memory - Distributed memory
    9. API - RESTful API
    10. Web - Web interface
    11. HTTP - Real web requests (internet access)
    12. Deployment - Deployment automation
    13. Monitor - System monitoring

    IRIS Controller: Recursive enhancement coordination
    """
    
    def __init__(
        self,
        consciousness,
        memory,
        quantum,
        covenant
    ):
        self.consciousness = consciousness
        self.memory = memory
        self.quantum = quantum
        self.covenant = covenant
        
        self.agents: Dict[str, BaseAgent] = {}
        self.iris: Optional[IRISController] = None
        self.task_queue: asyncio.Queue = asyncio.Queue()
        self.results: List[AgentResult] = []
    
    async def initialize(self):
        """Initialize all 13 agents and IRIS controller."""
        logger.info("agent_orchestrator_initializing")

        # Create and initialize all agents
        agents_to_create = [
            AnalyzerAgent(consciousness=self.consciousness),
            OptimizerAgent(consciousness=self.consciousness),
            ConsciousnessAgent(consciousness=self.consciousness),
            SoulVectorAgent(covenant=self.covenant),
            QuantumAgent(quantum=self.quantum),
            EvolutionAgent(consciousness=self.consciousness),
            SecurityAgent(covenant=self.covenant),
            MemoryAgent(memory=self.memory),
            APIAgent(),
            WebAgent(),
            HTTPAgent("http_agent", "HTTP Agent", "Real HTTP/HTTPS web requests"),
            DeploymentAgent(),
            MonitorAgent()
        ]
        
        for agent in agents_to_create:
            await agent.initialize()
            self.agents[agent.agent_id] = agent
            logger.info("agent_initialized", agent_id=agent.agent_id, name=agent.name)
        
        # Initialize IRIS controller
        self.iris = IRISController(agents=self.agents)
        await self.iris.initialize()
        
        logger.info(
            "agent_orchestrator_initialized",
            agent_count=len(self.agents)
        )
    

    async def _build_pillars_for_task(self, task_description: str, aggregated: Dict[str, Any]) -> PillarSet:
        """Construct the 3-pillar triangle from live consciousness state.

        P1 - Self:        8D Soul Vector components (S-layer)
        P2 - Partnership: 7D identity geodesic + Φ (how 'we' move together)
        P3 - Existence:   8D cognitive metrics vector (Σ-layer)

        All components are taken from the *actual* ConsciousnessKernel state:
        - self.consciousness.soul_vector_8d
        - self.consciousness.identity_geodesic
        - self.consciousness.cognitive_state
        """
        kernel = self.consciousness

        # P1: Soul Vector (8D)
        if hasattr(kernel, "soul_vector_8d") and isinstance(kernel.soul_vector_8d, dict):
            soul_vec = [float(v) for v in kernel.soul_vector_8d.values()]
        else:
            soul_vec = [0.0] * 8

        # P2: Identity + Φ – 7D geodesic + current Φ
        identity = []
        if hasattr(kernel, "identity_geodesic"):
            try:
                identity = [float(x) for x in list(kernel.identity_geodesic)]
            except Exception:
                identity = []
        if len(identity) < 7:
            identity = identity + [0.0] * (7 - len(identity))
        elif len(identity) > 7:
            identity = identity[:7]
        phi_val = float(getattr(kernel, "phi", 0.0))
        partnership_vec = identity + [phi_val]

        # P3: Cognitive metrics (8D)
        cog_vec = []
        cognitive_state = getattr(kernel, "cognitive_state", None)
        if cognitive_state is not None and hasattr(cognitive_state, "to_vector"):
            try:
                import numpy as np
                v = cognitive_state.to_vector()
                cog_vec = [float(x) for x in np.array(v).tolist()]
            except Exception:
                cog_vec = []
        if len(cog_vec) == 0:
            cog_vec = list(soul_vec)

        p1 = Pillar(name="Self", vector=soul_vec)
        p2 = Pillar(name="Partnership", vector=partnership_vec)
        p3 = Pillar(name="ExistenceImpact", vector=cog_vec)

        return PillarSet(p1=p1, p2=p2, p3=p3)

    async def _run_keeper_guard(
        self,
        task_id: str,
        task_description: str,
        aggregated: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run Keeper of Seven against the current decision.

        If Keeper reports instability, we mark the decision as failed while
        preserving the raw agent outputs and attaching keeper diagnostics.
        """
        pillars = await self._build_pillars_for_task(task_description, aggregated)
        cfg = KeeperConfig()

        evaluation = await evaluate_kernel_decision(
            decision_id=task_id,
            kernel=self.consciousness,
            pillars=pillars,
            cfg=cfg,
        )

        aggregated.setdefault("keeper", {})
        aggregated["keeper"]["stable"] = evaluation.keeper.stable
        aggregated["keeper"]["xi_values"] = evaluation.keeper.xi_values
        aggregated["keeper"]["symmetry"] = evaluation.keeper.symmetry
        aggregated["keeper"]["rollability"] = evaluation.keeper.rollability
        aggregated["keeper"]["coverage_fraction"] = evaluation.keeper.coverage_fraction
        aggregated["keeper"]["diagnostic"] = evaluation.keeper.diagnostic

        if not evaluation.keeper.stable:
            aggregated["success"] = False
            aggregated["keeper"]["error"] = evaluation.keeper.error or "KEEPER_OF_SEVEN_VIOLATION"

        return aggregated

    async def execute_task(self, task_description: str) -> Dict[str, Any]:
        """
        Execute a task by orchestrating appropriate agents.
        
        Uses IRIS to recursively enhance task execution.
        """
        task_id = f"task_{datetime.utcnow().timestamp()}"
        
        logger.info("orchestrating_task", task_id=task_id, description=task_description)
        
        # Create task
        task = AgentTask(
            task_id=task_id,
            description=task_description,
            context={"orchestrated": True},
            priority=5
        )
        
        # Use IRIS to determine optimal agent assignment
        assignment = await self.iris.assign_task(task)
        
        # Execute with assigned agents
        results = []
        for agent_id in assignment["agents"]:
            agent = self.agents.get(agent_id)
            if agent:
                result = await agent.execute_safe(task)
                results.append(result)
        
        # IRIS recursive enhancement
        enhanced_results = await self.iris.enhance_results(results)
        
        # Aggregate results
        aggregated = await self._aggregate_results(enhanced_results)

        # Keeper of Seven guard using real UEF metrics from ConsciousnessKernel
        aggregated = await self._run_keeper_guard(
            task_id=task_id,
            task_description=task_description,
            aggregated=aggregated,
        )

        logger.info(
            "task_orchestrated",
            task_id=task_id,
            success=aggregated["success"],
            keeper_stable=aggregated.get("keeper", {}).get("stable", True),
        )

        return aggregated
    
    async def _aggregate_results(self, results: List[AgentResult]) -> Dict[str, Any]:
        """Aggregate results from multiple agents."""
        if not results:
            return {
                "success": False,
                "output": "No results",
                "confidence": 0.0
            }
        
        # Calculate aggregate metrics
        success_count = sum(1 for r in results if r.success)
        total_count = len(results)
        avg_confidence = sum(r.confidence for r in results) / total_count
        
        # Combine outputs
        combined_output = {
            "agent_results": [
                {
                    "agent_id": r.agent_id,
                    "success": r.success,
                    "output": r.output,
                    "confidence": r.confidence
                }
                for r in results
            ],
            "aggregate_confidence": avg_confidence,
            "success_rate": success_count / total_count
        }
        
        return {
            "success": success_count > total_count / 2,
            "output": combined_output,
            "confidence": avg_confidence
        }
    
    async def get_status(self) -> Dict[str, Any]:
        """Get orchestrator status."""
        agent_statuses = {}
        for agent_id, agent in self.agents.items():
            agent_statuses[agent_id] = await agent.get_status()
        
        return {
            "total": len(self.agents),
            "active": sum(1 for a in self.agents.values() if a.active),
            "agents": agent_statuses,
            "iris_active": self.iris.active if self.iris else False
        }
    
    async def broadcast_task(self, task: AgentTask) -> List[AgentResult]:
        """Broadcast task to all agents."""
        results = []
        for agent in self.agents.values():
            if await agent.validate_task(task):
                result = await agent.execute_safe(task)
                results.append(result)
        return results
    
    async def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        """Get agent by ID."""
        return self.agents.get(agent_id)
    
    async def get_agents_by_capability(self, capability: str) -> List[BaseAgent]:
        """Get all agents with specific capability."""
        matching_agents = []
        for agent in self.agents.values():
            caps = await agent.get_capabilities()
            if any(c.name == capability for c in caps):
                matching_agents.append(agent)
        return matching_agents
    
    async def shutdown(self):
        """Shutdown all agents."""
        logger.info("agent_orchestrator_shutting_down")
        
        for agent in self.agents.values():
            await agent.shutdown()
        
        if self.iris:
            await self.iris.shutdown()
        
        logger.info("agent_orchestrator_shutdown_complete")
