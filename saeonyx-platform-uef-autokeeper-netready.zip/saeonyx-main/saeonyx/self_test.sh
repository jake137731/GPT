#!/bin/bash
# ======================================================
# SAEONYX SELF-TEST SUITE (Structural + Integrity Only)
# ======================================================

ROOT="/opt/saeonyx"
MODULES=(
  "foundation"
  "saeonyx"
  "saeonyx/agents"
  "saeonyx/api"
  "saeonyx/capabilities"
  "saeonyx/core"
  "saeonyx/digital_twin"
  "saeonyx/docs"
  "saeonyx/evolution"
  "saeonyx/genomics"
  "saeonyx/legacy"
  "saeonyx/memory"
  "saeonyx/monetization"
  "saeonyx/partnership"
  "saeonyx/quantum"
  "saeonyx/security"
  "saeonyx/web"
)

echo ">>> SAEONYX SYSTEM SELF-TEST BEGIN <<<"
echo

# 1. DIRECTORY CHECKS
echo "[1] Directory Checks"
for m in "${MODULES[@]}"; do
    if [ -d "$ROOT/$m" ]; then
        echo "  ✔  Found: $m"
    else
        echo "  ✖  MISSING: $m"
    fi
done

echo

# 2. KEY FILE CHECKS
echo "[2] Key File Checks"

FILES=(
  "foundation/STAGE0_PRIME_DIRECTIVE.md"
  "saeonyx/saeonyx_master.py"
  "saeonyx/GENESIS_LOADER.py"
  "saeonyx/GENESIS_PROMPT.txt"
  "saeonyx/requirements.txt"
)

for f in "${FILES[@]}"; do
    if [ -f "$ROOT/$f" ]; then
        echo "  ✔  File present: $f"
    else
        echo "  ✖  Missing file: $f"
    fi
done

echo

# 3. PERMISSION CHECKS
echo "[3] Permission Checks"

if [ -f "$ROOT/foundation/STAGE0_PRIME_DIRECTIVE.md" ]; then
    perms=$(stat -c "%a" "$ROOT/foundation/STAGE0_PRIME_DIRECTIVE.md")
    echo "  Prime Directive permissions: $perms"
    if [ "$perms" != "440" ]; then
        echo "  ✖  WARNING: Prime Directive should be read-only (440)"
    else
        echo "  ✔  Prime Directive correctly locked"
    fi
fi

echo

# 4. PYTHON IMPORT TESTS (non-executing)
echo "[4] Python Import Structure"

python3 - << 'EOF'
import pkgutil, sys
import os

root = "/opt/saeonyx/saeonyx"
print("Modules reachable:")

for importer, modname, ispkg in pkgutil.walk_packages([root]):
    print("  ✔", modname)
EOF

echo
echo ">>> SAEONYX SELF-TEST COMPLETE <<<"