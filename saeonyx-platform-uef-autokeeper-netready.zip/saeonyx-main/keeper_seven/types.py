from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple


Vector = List[float]


@dataclass
class Pillar:
    name: str
    vector: Vector


@dataclass
class PillarSet:
    p1: Pillar
    p2: Pillar
    p3: Pillar


@dataclass
class EmergenceMetrics:
    decision_effort: float
    flow_gradient: float
    mass_gap: float
    spectral_deviation: float
    meaning_rank_diff: float
    repr_mismatch: float
    noncontractible_loops: float


@dataclass
class KeeperResult:
    stable: bool
    xi_values: Dict[str, float]
    symmetry: float
    rollability: float
    coverage_fraction: float
    diagnostic: Dict[str, Any]
    error: Optional[str] = None


SymmetryResult = Tuple[float, Dict[str, float]]
RollabilityResult = float
