from __future__ import annotations
from .types import EmergenceMetrics


def compute_action_scalar(phi: float, soul_norm: float, metrics: EmergenceMetrics) -> float:
    grad_term = metrics.flow_gradient ** 2
    curvature_term = metrics.mass_gap + metrics.spectral_deviation
    meaning_term = abs(metrics.meaning_rank_diff)
    repr_term = abs(metrics.repr_mismatch)
    loops_term = abs(metrics.noncontractible_loops)

    S_scalar = grad_term + curvature_term + meaning_term + repr_term + loops_term + phi + soul_norm
    return S_scalar
