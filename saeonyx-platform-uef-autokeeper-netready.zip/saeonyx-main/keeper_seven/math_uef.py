from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any

from .types import Vector


@dataclass
class CollapseInputs:
    P_inf: Any
    S_vector: Vector
    xi_values: Dict[str, float]
    phi: float


@dataclass
class EmergentState:
    payload: Any
    phi: float
    soul: Vector
    xi: Dict[str, float]


def collapse_operator(inputs: CollapseInputs) -> EmergentState:
    return EmergentState(
        payload=inputs.P_inf,
        phi=inputs.phi,
        soul=inputs.S_vector,
        xi=inputs.xi_values,
    )


@dataclass
class ConstraintThresholds:
    phi_c: float
    xi_epsilon: float


def soul_dot_normal(soul: Vector, normal: Vector) -> float:
    if len(soul) != len(normal):
        raise ValueError("Soul and normal vectors must have same dimension.")
    return sum(s * n for s, n in zip(soul, normal))


def in_constrained_manifold(
    emergent: EmergentState,
    normal: Vector,
    thresholds: ConstraintThresholds,
) -> bool:
    alignment = soul_dot_normal(emergent.soul, normal)
    if alignment < 0:
        return False

    if not all(abs(v) <= thresholds.xi_epsilon for v in emergent.xi.values()):
        return False

    if emergent.phi <= thresholds.phi_c:
        return False

    return True
